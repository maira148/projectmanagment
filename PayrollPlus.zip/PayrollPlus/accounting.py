import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import io

def accounting_page():
    st.title("📂 Accounting Automation System - by Maira")

    uploaded_file = st.file_uploader("📤 Upload CSV or Excel file", type=["csv", "xlsx"])
    if uploaded_file:
        # Read data
        if uploaded_file.name.endswith(".csv"):
            data = pd.read_csv(uploaded_file)
        else:
            data = pd.read_excel(uploaded_file)

        st.success("✅ File uploaded!")
        st.dataframe(data.head())

        task = st.radio("Select Task", ["Summary", "Payroll", "Bookkeeping", "Balance Sheet", "Download Final File"])
        added_sections = {}

        # ---------- SUMMARY ----------
        if task == "Summary":
            st.subheader("📌 File Summary")
            st.write(data.describe(include='all'))

            st.subheader("📊 Chart Visualization")
            chart_type = st.selectbox("Choose Chart Type", ["Bar Chart", "Pie Chart", "Line Chart", "Area Chart"])
            numeric_columns = data.select_dtypes(include='number').columns
            if numeric_columns.empty:
                st.warning("⚠️ No numeric columns found for plotting.")
                return
            column = st.selectbox("Choose Column for Chart", numeric_columns)
            chart_color = st.color_picker("🎨 Pick Chart Color", "#3498db")
            theme = st.selectbox("📚 Seaborn Theme", ["darkgrid", "whitegrid", "dark", "white", "ticks"])
            sns.set_theme(style=theme)

            fig, ax = plt.subplots()
            if chart_type == "Bar Chart":
                sns.barplot(x=data.index, y=data[column], ax=ax, color=chart_color)
            elif chart_type == "Pie Chart":
                data[column].value_counts().plot.pie(autopct="%1.1f%%", colors=[chart_color], ax=ax)
            elif chart_type == "Line Chart":
                sns.lineplot(data=data[column], ax=ax, color=chart_color)
            elif chart_type == "Area Chart":
                data[column].plot.area(ax=ax, color=chart_color)

            st.pyplot(fig)

        # ---------- PAYROLL ----------
        elif task == "Payroll":
            st.subheader("🧾 Payroll Processing")
            employee_col = st.selectbox("Employee Column", data.columns)
            salary_col = st.selectbox("Base Salary Column", data.select_dtypes(include='number').columns)
            overtime_cols = st.multiselect("Overtime Column(s)", data.select_dtypes(include='number').columns)
            deduction_cols = st.multiselect("Deduction Column(s)", data.select_dtypes(include='number').columns)
            add_to_file = st.checkbox("➕ Add Payroll Columns to Main File", value=True)

            df = data.copy()

            df["Overtime"] = df[overtime_cols].sum(axis=1) if overtime_cols else 0
            df["Deductions"] = df[deduction_cols].sum(axis=1) if deduction_cols else 0
            df["Net Pay"] = df[salary_col] + df["Overtime"] - df["Deductions"]

            payroll_df = df[[employee_col, salary_col, "Overtime", "Deductions", "Net Pay"]]
            payroll_df.columns = ["Employee", "Base Salary", "Overtime", "Deductions", "Net Pay"]

            st.dataframe(payroll_df)

            fig, ax = plt.subplots()
            sns.barplot(x="Employee", y="Net Pay", data=payroll_df, ax=ax)
            plt.xticks(rotation=45)
            st.pyplot(fig)

            csv = payroll_df.to_csv(index=False).encode()
            st.download_button("📥 Download Payroll Report (CSV)", csv, "payroll.csv", "text/csv")

            if add_to_file:
                data["Overtime"] = df["Overtime"]
                data["Deductions"] = df["Deductions"]
                data["Net Pay"] = df["Net Pay"]
                added_sections["payroll"] = True

        # ---------- BOOKKEEPING ----------
        elif task == "Bookkeeping":
            st.subheader("📒 Bookkeeping")
            numeric_columns = data.select_dtypes(include='number').columns
            if numeric_columns.empty:
                st.warning("⚠️ No numeric columns found.")
                return
            amount_col = st.selectbox("Amount Column", numeric_columns)
            category_col = st.selectbox("Category Column", data.columns)
            add_to_file = st.checkbox("➕ Add Bookkeeping Totals to File", value=True)

            summary = data.groupby(category_col)[amount_col].sum().reset_index()
            summary.columns = ["Category", "Total"]
            st.dataframe(summary)

            fig, ax = plt.subplots()
            sns.barplot(x="Category", y="Total", data=summary, ax=ax)
            plt.xticks(rotation=45)
            st.pyplot(fig)

            fig2, ax2 = plt.subplots()
            summary.set_index("Category").plot.pie(y="Total", autopct="%1.1f%%", ax=ax2)
            st.pyplot(fig2)

            csv = summary.to_csv(index=False).encode()
            st.download_button("📥 Download Bookkeeping Report (CSV)", csv, "bookkeeping.csv", "text/csv")

            if add_to_file:
                category_map = dict(zip(summary["Category"], summary["Total"]))
                data["Bookkeeping_Total"] = data[category_col].map(category_map)
                added_sections["bookkeeping"] = True

        # ---------- BALANCE SHEET ----------
        elif task == "Balance Sheet":
            st.subheader("📉 Balance Sheet")
            asset_col = st.selectbox("Asset Column", ["None"] + list(data.columns))
            liability_col = st.selectbox("Liability Column", ["None"] + list(data.columns))
            equity_col = st.selectbox("Equity Column", ["None"] + list(data.columns))
            add_to_file = st.checkbox("➕ Add Balance Sheet Row to File", value=True)

            try:
                assets = data[asset_col].sum() if asset_col != "None" else 0
                liabilities = data[liability_col].sum() if liability_col != "None" else 0
                equity = data[equity_col].sum() if equity_col != "None" else (assets - liabilities)
            except:
                st.error("❌ Invalid numeric columns selected.")
                return

            balance_df = pd.DataFrame({
                "Category": ["Assets", "Liabilities", "Equity"],
                "Amount": [assets, liabilities, equity]
            })

            st.dataframe(balance_df)

            fig, ax = plt.subplots()
            sns.barplot(x="Category", y="Amount", data=balance_df, ax=ax)
            st.pyplot(fig)

            csv = balance_df.to_csv(index=False).encode()
            st.download_button("📥 Download Balance Sheet (CSV)", csv, "balance_sheet.csv", "text/csv")

            if add_to_file:
                data.loc[len(data.index)] = [None] * len(data.columns)
                for i, row in balance_df.iterrows():
                    data.loc[len(data.index)] = [row["Category"]] + [row["Amount"]] + [None] * (len(data.columns) - 2)
                added_sections["balance"] = True

        # ---------- FINAL FILE DOWNLOAD ----------
        elif task == "Download Final File":
            st.subheader("⬇️ Download Modified File")
            if added_sections:
                # CSV
                csv = data.to_csv(index=False).encode()
                st.download_button("📥 Download CSV File", csv, "final_output.csv", "text/csv")

                # Excel
                output = io.BytesIO()
                with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
                    data.to_excel(writer, index=False, sheet_name='Modified Data')
                output.seek(0)
                st.download_button(
                    "📥 Download Excel File",
                    output.read(),
                    "final_output.xlsx",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
            else:
                st.warning("⚠️ You have not added any reports to the file yet.")
