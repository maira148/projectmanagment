import streamlit as st
from auth import login_user, signup_user
from accounting import accounting_page
from accounting_pro import pro_accounting_page  # Import the pro module

st.set_page_config(page_title="PayrollPlus", layout="wide", page_icon="💼")

# Initialize session state
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "username" not in st.session_state:
    st.session_state.username = None

def main():
    st.markdown("""
        <style>
            .main {background-color: #f7f9fb;}
            .css-1d391kg, .css-1lcbmhc {
                background-color: #ffffff;
                border-radius: 15px;
                padding: 2rem;
                box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            }
            .stButton>button {
                color: white;
                background-color: #4CAF50;
                border: none;
                padding: 0.6em 1.2em;
                border-radius: 8px;
            }
            .stSelectbox, .stFileUploader, .stMultiSelect {
                background-color: #f0f2f6 !important;
                border-radius: 8px;
            }
        </style>
    """, unsafe_allow_html=True)

    st.title("💼 PayrollPlus")

    if not st.session_state.logged_in:
        menu = ["Login", "SignUp"]
        choice = st.sidebar.selectbox("Select Option", menu)

        if choice == "Login":
            username = st.text_input("Username")
            password = st.text_input("Password", type='password')
            if st.button("Login"):
                if login_user(username, password):
                    st.session_state.logged_in = True
                    st.session_state.username = username
                    st.success("Logged in successfully")
                else:
                    st.error("Invalid credentials")
        else:
            new_user = st.text_input("New Username")
            new_pass = st.text_input("New Password", type='password')
            if st.button("Create Account"):
                if signup_user(new_user, new_pass):
                    st.success("Account created. Please log in.")
    else:
        st.sidebar.success(f"Logged in as {st.session_state.username}")
        if st.sidebar.button("Logout"):
            st.session_state.logged_in = False
            st.session_state.username = None
            st.experimental_rerun()

        # Module Selector
        app_section = st.sidebar.radio("Select Module", ["📋 Accounting", "📊 Accounting Pro"])

        if app_section == "📋 Accounting":
            accounting_page()
        elif app_section == "📊 Accounting Pro":
            pro_accounting_page()

if __name__ == '__main__':
    main()
