import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from io import BytesIO
from datetime import datetime

sns.set_theme(style="whitegrid")

# ---------------------- Sidebar & Header ----------------------

# ---------------------- Invoice Generator ----------------------
def generate_invoice(data, company_name="Your Company"):
    buffer = BytesIO()
    df = data.copy()
    df["Total"] = df["Quantity"] * df["Unit Price"]
    total_amount = df["Total"].sum()

    invoice = f"""
    Invoice - {company_name}\n
    Date: {datetime.now().strftime('%Y-%m-%d')}
    -----------------------------------------
    """
    for _, row in df.iterrows():
        invoice += f"{row['Item']} - {row['Quantity']} x {row['Unit Price']} = {row['Total']}\n"
    invoice += f"\nTotal Due: {total_amount}\n\nThank you for your business!"

    buffer.write(invoice.encode())
    return buffer

# ---------------------- Financial Ratios ----------------------
def financial_ratios(df):
    st.markdown("### 📈 <span style='color:teal'>Financial KPIs</span>", unsafe_allow_html=True)
    asset = st.number_input("💰 Total Assets", value=10000.0)
    liability = st.number_input("📉 Total Liabilities", value=4000.0)
    revenue = st.number_input("📊 Revenue", value=12000.0)
    expense = st.number_input("💸 Expenses", value=6000.0)
    equity = asset - liability
    net_income = revenue - expense

    st.success(f"✅ Net Income: {net_income}")
    st.markdown(f"""
    - **Net Profit Margin**: {net_income / revenue:.2%}
    - **Current Ratio**: {asset / liability:.2f}
    - **Debt to Equity**: {liability / equity:.2f}
    - **Return on Equity**: {net_income / equity:.2%}
    """)

# ---------------------- Tax Calculator ----------------------
def tax_calculator(df):
    st.markdown("### 💰 <span style='color:green'>Smart Tax Calculator</span>", unsafe_allow_html=True)

    numeric_cols = df.select_dtypes(include='number').columns
    if len(numeric_cols) == 0:
        st.error("❌ No numeric columns found for tax calculation.")
        return

    income_col = st.selectbox("Choose Income Column", numeric_cols)
    tax_rate = st.slider("Tax Rate (%)", 0, 50, 15)

    df["Estimated Tax"] = df[income_col] * (tax_rate / 100)
    st.dataframe(df[[income_col, "Estimated Tax"]])

    csv = df.to_csv(index=False).encode()
    st.download_button("📥 Download Tax Report", csv, "tax_report.csv", "text/csv")

# ---------------------- Cash Flow Tracker ----------------------
def cashflow(df):
    st.markdown("### 📊 <span style='color:orange'>Cash Flow Tracker</span>", unsafe_allow_html=True)

    numeric_cols = df.select_dtypes(include='number').columns
    if len(numeric_cols) == 0:
        st.error("❌ No numeric columns found for cash flow tracking.")
        return

    amount_col = st.selectbox("Amount Column", numeric_cols)
    inflow_outflow = st.selectbox("Inflow/Outflow Column", df.columns)

    summary = df.groupby(inflow_outflow)[amount_col].sum().reset_index()
    st.dataframe(summary)

    fig, ax = plt.subplots()
    sns.barplot(x=inflow_outflow, y=amount_col, data=summary, ax=ax, palette="viridis")
    st.pyplot(fig)

# ---------------------- Balance Check ----------------------
def balance_check(df):
    st.markdown("### 📉 <span style='color:red'>Audit Balance Check</span>", unsafe_allow_html=True)

    all_columns = ["None"] + list(df.columns)
    asset_col = st.selectbox("Asset Column", all_columns)
    liability_col = st.selectbox("Liability Column", all_columns)
    equity_col = st.selectbox("Equity Column", all_columns)

    try:
        assets = df[asset_col].sum() if asset_col != "None" else 0
        liabilities = df[liability_col].sum() if liability_col != "None" else 0
        equity = df[equity_col].sum() if equity_col != "None" else (assets - liabilities)
    except Exception as e:
        st.error(f"⚠️ Error: {e}")
        return

    st.markdown(f"""
    - **Assets**: {assets}
    - **Liabilities**: {liabilities}
    - **Equity**: {equity}
    - ✅ **Balanced**: {assets == liabilities + equity}
    """)

    chart_df = pd.DataFrame({
        "Category": ["Assets", "Liabilities", "Equity"],
        "Amount": [assets, liabilities, equity]
    })

    fig, ax = plt.subplots()
    sns.barplot(x="Category", y="Amount", data=chart_df, ax=ax, palette="pastel")
    st.pyplot(fig)

# ---------------------- Multi-Sheet Export ----------------------
def multi_sheet_export(sheets_dict):
    buffer = BytesIO()
    with pd.ExcelWriter(buffer, engine='xlsxwriter') as writer:
        for sheet_name, df in sheets_dict.items():
            df.to_excel(writer, sheet_name=sheet_name, index=False)
    return buffer

# ---------------------- Main Pro Accounting Page ----------------------
def pro_accounting_page():
    st.title("📊 Accounting Dashboard")

    uploaded_file = st.file_uploader("📥 Upload CSV or Excel", type=["csv", "xlsx"])

    if uploaded_file:
        try:
            df = pd.read_csv(uploaded_file) if uploaded_file.name.endswith(".csv") else pd.read_excel(uploaded_file)
            st.success("✅ File uploaded successfully.")
            st.dataframe(df.head())
        except Exception as e:
            st.error(f"❌ Failed to read file: {e}")
            return

        task = st.selectbox("Select Feature", [
            "📌 Smart Tax Calculator",
            "📈 Financial Ratios",
            "📊 Cash Flow Tracker",
            "🧾 Generate PDF Invoice",
            "📉 Audit Balance Sheet",
            "📤 Export All Reports (Multi-Sheet)"
        ])

        if task == "📌 Smart Tax Calculator":
            tax_calculator(df)

        elif task == "📈 Financial Ratios":
            financial_ratios(df)

        elif task == "📊 Cash Flow Tracker":
            cashflow(df)

        elif task == "🧾 Generate PDF Invoice":
            st.markdown("### 🧾 <span style='color:blue'>Invoice Generator</span>", unsafe_allow_html=True)

            try:
                item_col = st.selectbox("Item Column", df.columns)
                qty_col = st.selectbox("Quantity Column", df.columns)
                price_col = st.selectbox("Unit Price Column", df.columns)

                inv_df = df[[item_col, qty_col, price_col]].rename(columns={
                    item_col: "Item",
                    qty_col: "Quantity",
                    price_col: "Unit Price"
                })

                invoice = generate_invoice(inv_df)
                st.download_button("📥 Download Invoice (Text)", invoice, "invoice.txt")
            except Exception as e:
                st.error(f"⚠️ Unable to generate invoice: {e}")

        elif task == "📉 Audit Balance Sheet":
            balance_check(df)

        elif task == "📤 Export All Reports (Multi-Sheet)":
            sheets = {
                "Original": df,
                "Summary": df.describe().reset_index(),
            }
            xlsx_data = multi_sheet_export(sheets)
            st.download_button("📥 Download Excel with All Sheets", xlsx_data, "accounting_report.xlsx")
    else:
        st.info("👈 Upload a file to get started.")

# Run the app
if __name__ == "__main__":
    pro_accounting_page()
